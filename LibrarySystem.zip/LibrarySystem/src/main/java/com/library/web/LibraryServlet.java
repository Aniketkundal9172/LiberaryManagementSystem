// File: src/main/java/com/library/web/LibraryServlet.java
package com.library.web;

import com.library.exceptions.BookNotFoundException;
import com.library.exceptions.BookUnavailableException;
import com.library.exceptions.DuplicateBookException;
import com.library.model.Book;
import com.library.service.LibraryService;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet(name = "LibraryServlet", urlPatterns = {"/library"})
public class LibraryServlet extends HttpServlet {
    private LibraryService libraryService;

    @Override
    public void init() {
        ServletContext context = getServletContext();
        libraryService = new LibraryService(context.getRealPath(""));
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String message = null;
        String error = null;
        
        try {
            switch (action) {
                case "add":
                    addBook(request);
                    message = "Book added successfully!";
                    break;
                case "update":
                    updateBook(request);
                    message = "Book updated successfully!";
                    break;
                case "remove":
                    removeBook(request);
                    message = "Book removed successfully!";
                    break;
                case "borrow":
                    borrowBook(request);
                    message = "Book borrowed successfully!";
                    break;
                case "return":
                    returnBook(request);
                    message = "Book returned successfully!";
                    break;
            }
        } catch (DuplicateBookException | BookNotFoundException | BookUnavailableException e) {
            error = e.getMessage();
        } catch (NumberFormatException e) {
            error = "Invalid year format!";
        } catch (Exception e) {
            error = "Error: " + e.getMessage();
        }
        
        request.setAttribute("message", message);
        request.setAttribute("error", error);
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action == null) {
            listAllBooks(request);
            request.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(request, response);
            return;
        }
        
        switch (action) {
            case "search":
                searchBooks(request);
                request.getRequestDispatcher("/WEB-INF/views/searchResults.jsp").forward(request, response);
                break;
            case "advancedSearch":
                advancedSearch(request);
                request.getRequestDispatcher("/WEB-INF/views/advancedSearch.jsp").forward(request, response);
                break;
            default:
                listAllBooks(request);
                request.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(request, response);
        }
    }

    private void addBook(HttpServletRequest request) throws DuplicateBookException {
        String isbn = request.getParameter("isbn");
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        int year = Integer.parseInt(request.getParameter("year"));
        
        libraryService.addBook(new Book(isbn, title, author, year));
    }

    private void updateBook(HttpServletRequest request) throws BookNotFoundException {
        String isbn = request.getParameter("isbn");
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        int year = Integer.parseInt(request.getParameter("year"));
        
        libraryService.updateBook(isbn, title, author, year);
    }

    private void removeBook(HttpServletRequest request) throws BookNotFoundException {
        String isbn = request.getParameter("isbn");
        libraryService.removeBook(isbn);
    }

    private void borrowBook(HttpServletRequest request) throws BookNotFoundException, BookUnavailableException {
        String isbn = request.getParameter("isbn");
        String borrower = request.getParameter("borrower");
        libraryService.borrowBook(isbn, borrower);
    }

    private void returnBook(HttpServletRequest request) throws BookNotFoundException {
        String isbn = request.getParameter("isbn");
        libraryService.returnBook(isbn);
    }

    private void listAllBooks(HttpServletRequest request) {
        request.setAttribute("books", libraryService.getAllBooks());
    }

    private void searchBooks(HttpServletRequest request) {
        String term = request.getParameter("term");
        request.setAttribute("titleResults", libraryService.searchByTitle(term));
        request.setAttribute("authorResults", libraryService.searchByAuthor(term));
        request.setAttribute("searchTerm", term);
    }

    private void advancedSearch(HttpServletRequest request) {
        String query = request.getParameter("query");
        Map<Book, Integer> results = libraryService.searchWithScoring(query);
        request.setAttribute("searchResults", results);
        request.setAttribute("searchQuery", query);
    }
}