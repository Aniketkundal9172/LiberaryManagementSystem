// File: src/main/java/com/library/model/Book.java
package com.library.model;

import java.io.Serializable;

public class Book implements Serializable {
    private final String isbn;
    private String title;
    private String author;
    private int publicationYear;
    private boolean isAvailable;
    private String borrower;

    public Book(String isbn, String title, String author, int publicationYear) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
        this.isAvailable = true;
        this.borrower = null;
    }

    // Getters and Setters
    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public int getPublicationYear() { return publicationYear; }
    public void setPublicationYear(int publicationYear) { this.publicationYear = publicationYear; }
    public boolean isAvailable() { return isAvailable; }
    public String getBorrower() { return borrower; }

    // Borrow and Return operations
    public void borrowBook(String borrower) {
        this.isAvailable = false;
        this.borrower = borrower;
    }

    public void returnBook() {
        this.isAvailable = true;
        this.borrower = null;
    }

    @Override
    public String toString() {
        return "Book{" +
                "isbn='" + isbn + '\'' +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", publicationYear=" + publicationYear +
                ", isAvailable=" + isAvailable +
                ", borrower='" + borrower + '\'' +
                '}';
    }
}