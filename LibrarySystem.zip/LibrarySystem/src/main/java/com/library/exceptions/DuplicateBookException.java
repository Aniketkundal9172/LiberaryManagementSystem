// File: src/main/java/com/library/exceptions/DuplicateBookException.java
package com.library.exceptions;

public class DuplicateBookException extends Exception {
    public DuplicateBookException(String message) {
        super(message);
    }
}