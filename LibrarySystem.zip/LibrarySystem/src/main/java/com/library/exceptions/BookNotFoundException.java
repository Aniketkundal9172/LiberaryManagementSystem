// File: src/main/java/com/library/exceptions/BookNotFoundException.java
package com.library.exceptions;

public class BookNotFoundException extends Exception {
    public BookNotFoundException(String message) {
        super(message);
    }
}