
// File: src/main/java/com/library/service/LibraryService.java
package com.library.service;

import com.library.exceptions.BookNotFoundException;
import com.library.exceptions.BookUnavailableException;
import com.library.exceptions.DuplicateBookException;
import com.library.model.Book;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class LibraryService {
    private final Map<String, Book> booksByIsbn;
    private final List<Book> allBooks;
    private final String dataFilePath;
    
    private static final String DATA_DIR = "library_data";
    private static final String DATA_FILE = "library_data.ser";

    public LibraryService(String contextPath) {
        this.booksByIsbn = new HashMap<>();
        this.allBooks = new ArrayList<>();
        this.dataFilePath = createDataDirectory(contextPath) + File.separator + DATA_FILE;
        loadBooksFromFile();
    }

    private String createDataDirectory(String contextPath) {
        String dataDirPath = contextPath + File.separator + DATA_DIR;
        File dataDir = new File(dataDirPath);
        if (!dataDir.exists()) {
            dataDir.mkdirs();
        }
        return dataDirPath;
    }

    // File Handling
    private void loadBooksFromFile() {
        File file = new File(dataFilePath);
        if (!file.exists()) {
            return;
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(dataFilePath))) {
            List<Book> savedBooks = (List<Book>) ois.readObject();
            allBooks.addAll(savedBooks);
            allBooks.forEach(book -> booksByIsbn.put(book.getIsbn(), book));
        } catch (FileNotFoundException e) {
            System.out.println("No existing data file. Starting fresh library.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading data: " + e.getMessage());
        }
    }

    public void saveBooksToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(dataFilePath))) {
            oos.writeObject(allBooks);
        } catch (IOException e) {
            System.err.println("Error saving data: " + e.getMessage());
        }
    }

    // Book Operations
    public void addBook(Book book) throws DuplicateBookException {
        if (booksByIsbn.containsKey(book.getIsbn())) {
            throw new DuplicateBookException("Book with ISBN " + book.getIsbn() + " already exists!");
        }
        booksByIsbn.put(book.getIsbn(), book);
        allBooks.add(book);
        saveBooksToFile();
    }

    public void removeBook(String isbn) throws BookNotFoundException {
        if (!booksByIsbn.containsKey(isbn)) {
            throw new BookNotFoundException("Book with ISBN " + isbn + " not found!");
        }
        Book book = booksByIsbn.remove(isbn);
        allBooks.remove(book);
        saveBooksToFile();
    }

    public void updateBook(String isbn, String title, String author, int year) 
            throws BookNotFoundException {
        Book book = getBookByIsbn(isbn);
        book.setTitle(title);
        book.setAuthor(author);
        book.setPublicationYear(year);
        saveBooksToFile();
    }

    public void borrowBook(String isbn, String borrower) 
            throws BookNotFoundException, BookUnavailableException {
        Book book = getBookByIsbn(isbn);
        if (!book.isAvailable()) {
            throw new BookUnavailableException("Book is already borrowed!");
        }
        book.borrowBook(borrower);
        saveBooksToFile();
    }

    public void returnBook(String isbn) throws BookNotFoundException {
        Book book = getBookByIsbn(isbn);
        book.returnBook();
        saveBooksToFile();
    }

    // Search Operations (String Manipulation + Collections)
    public List<Book> searchByTitle(String keyword) {
        return allBooks.stream()
                .filter(book -> book.getTitle().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
    }

    public List<Book> searchByAuthor(String keyword) {
        return allBooks.stream()
                .filter(book -> book.getAuthor().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
    }

    public Book getBookByIsbn(String isbn) throws BookNotFoundException {
        Book book = booksByIsbn.get(isbn);
        if (book == null) {
            throw new BookNotFoundException("Book with ISBN " + isbn + " not found!");
        }
        return book;
    }

    public List<Book> getAllBooks() {
        return Collections.unmodifiableList(allBooks);
    }

    // Keyword scoring for search relevance
    public Map<Book, Integer> searchWithScoring(String query) {
        Map<Book, Integer> scores = new HashMap<>();
        String[] keywords = query.toLowerCase().split("\\s+");

        for (Book book : allBooks) {
            int score = 0;
            String bookText = (book.getTitle() + " " + book.getAuthor() + " " + book.getIsbn()).toLowerCase();
            
            for (String keyword : keywords) {
                if (bookText.contains(keyword)) {
                    score += 3; // Base score for keyword match
                    
                    // Higher score for title matches
                    if (book.getTitle().toLowerCase().contains(keyword)) {
                        score += 2;
                    }
                }
            }
            
            if (score > 0) {
                scores.put(book, score);
            }
        }
        
        return scores.entrySet().stream()
                .sorted(Map.Entry.<Book, Integer>comparingByValue().reversed())
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));
    }
}